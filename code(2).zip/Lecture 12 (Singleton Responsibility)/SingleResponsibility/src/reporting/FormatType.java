package reporting;


public enum FormatType {
		XML, CSV
	}
